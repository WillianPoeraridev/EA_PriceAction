# Ambiguidades & Decisões
- [A-0001] <descrição>
  - Opções: A | B | C
  - Decisão atual: <A/B/C> (data, motivo)
  - Impacto em regras: R-0001, R-0003
