# Glossário
- **Barra de tendência (bull/bear)** — <definição objetiva: corpo vs range, contexto>
- **Pullback** — <quantos pés? profundidade mínima/máx>
- **Second Entry** — <condição de sequência/falha>
- **Respeitar EMA** — <toques/rejeições/fechamento acima-abaixo; tolerância>
