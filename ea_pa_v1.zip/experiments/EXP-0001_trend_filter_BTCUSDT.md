# EXP-0001 — Trend Filter (Brooks v0) — BTCUSDT SPOT
**Objetivo:** medir win%, payoff e DD operando H1 somente quando D/W em alta.

**Dados:** BTCUSDT Spot (H1/H4/D/W, 2–3 anos, EMA20/50 do pipeline atual)
**Critérios/labels:** sinal quando `R-0001.logic.entry_window` verdadeiro (fechamento H1).
**Métricas:** trades, win%, avgR, maxDD, SQN.

**Resultados (resumo):**
- ...

**Observações & próximos passos:**
- ...
