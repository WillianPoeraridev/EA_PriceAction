# EA Price Action — v1


## SPOT Downloader + MTF + EMA demo
```
python -m src.app.run_mtf_with_ema BTCUSDT 300
```
Gera `data/BTCUSDT_mtf_with_ema.csv` com closes e EMA20/EMA50 de H1/H4/D/W.
